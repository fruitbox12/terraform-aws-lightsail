# Welcome

You have just created a Project to use with Vagrant, Virtualbox, and Ansible!  Congratulations!

# Usage

Read the `*vagrant/README.md`, and get the required software installed and downloaded.

Out of the box, at the end of the README.md, you should be able to have a successful `vagrant up`.

Next, edit your files as necessary for further customization:

* `vagrant/Vagrantfile`
  * You can make changes to the local virtual machine definition, or add additional ansible playbooks to be run on `vagrant up`

* `ansible/group_vars`
  * You can add additional ansible tasks that require sudo access to run

* `ansible/host_vars`
  * You can add additional ansible tasks that require sudo access to run

* `ansible/roles`
  * You can add additional ansible tasks that require sudo access to run

* `ansible/README.md`
  * Keep your readme up to date!

* `vagrant/README.md`
  * Keep your readme up to date!

* `README.md`
  * Keep your readme up to date!

## directory guide

* testnet-inventory.yml     # inventory file for testnet

* group_vars/
  * testnet.yml             # here we assign group variables to testnet

* host_vars/
  * testnet.yml             # here we assign host variables to testnet

* testnet.yml               # playbook for testnet

* roles/
*     common/               # this hierarchy represents a "role"
*         tasks/            #
*             main.yml      #  <-- tasks file can include smaller files if warranted
*         handlers/         #
*             main.yml      #  <-- handlers file
*         files/             #
*             id_rsa.pub      #  <-- this is your local workstation user id pub key
*             ansible_rsa.pub #  <-- this is your local workstation ansible user pub key
*             ansible.txt     #  <-- this is the encrypted ansible vault password
*         vars/             #
*             main.yml      #  <-- variables associated with this role
*         defaults/         #
*             main.yml      #  <-- default lower priority variables for this role
*     testnet/              # same kind of structure as "common" was above, done for the webtier role

* `vagrant`
  * This is where we control our local vagrant setup

## control node setup
* `add your local user admin account keys to your local control node for ansible`
  * This is where you need to take the id_rsa and id_rsa.pub generated for your admin account
  and place them under ansible/roles/common/files
* `add a provision user to your local control node for ansible`
  * This is where you need to take the ansible_rsa file and place it under
  ansible/roles/common/files.  Also place the ansible_rsa.pub key under ansible/roles/common/files

## git commands
* git add .
* git commit -m "Initial Commit"
* git remote add node ssh://user@<git url>
* git push node origin

# This role requires a GitHub personal access token. Generate a new token (Settings -> Developer Settings -> Personal Acess Token). Make sure the token has the scopes outlined in the "Role Variables" section below.
* Create a password file that will be used to encrypt the GitHub personal access token
* echo "<your-passphrase>" | openssl aes-256-cbc -a -salt > ansible/roles/common/files/ansible.txt
* Encrypt the token by running the following command
* ansible-vault encrypt_string '<token>' --name 'github_access_token' --vault-password-file=/path/to/password/file
* Copy the generated encrypted string and paste it in the vars/main.yml file
