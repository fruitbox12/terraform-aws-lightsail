#!/usr/bin/env bash
set -e
export NODECLI_WORKDIR=$(cd $(dirname $0) && pwd)
. "$NODECLI_WORKDIR/common"

cli_help() {
  cli_name=${0##*/}
  echo "
$cli_name
Brot and Games CLI
Version: $(cat $NODECLI_WORKDIR/VERSION)
Usage: $cli_name [command]
Commands:
  deploy    Deploy
  *         Help
"
  exit 1
}

cli_log "Exporting config ..."
export $(cat "$NODECLI_WORKDIR/config" | xargs)

case "$1" in
  deploy|d)
    "$NODECLI_WORKDIR/commands/deploy" "$2" | tee -ia "$NODECLI_WORKDIR/deploy_${2}.log"
    ;;
  *)
    cli_help
    ;;
esac
